function submitForm(){
  var form1Value = document.getElementsByClassName('form-control').value;
  if (form1Value == ""){
    alert("Name must be filled out");
    return false;
  } else{
    console.log(form1Value);
  }
}
